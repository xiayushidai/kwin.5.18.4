/usr/bin/kpackagetool5 --generate-index -g -p /usr/share/kwin/scripts
