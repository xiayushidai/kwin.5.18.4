sendTestResponse(displayWidth() + "x" + displayHeight());
sendTestResponse(animationTime(100));

//test enums for Effect / QEasingCurve
sendTestResponse(Effect.Saturation)
sendTestResponse(QEasingCurve.Linear)
