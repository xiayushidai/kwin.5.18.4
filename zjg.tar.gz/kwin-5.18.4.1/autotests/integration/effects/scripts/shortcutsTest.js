registerShortcut("testShortcut", "Test Shortcut", "Meta+Shift+Y", function() {
    sendTestResponse("shortcutTriggered");
});
