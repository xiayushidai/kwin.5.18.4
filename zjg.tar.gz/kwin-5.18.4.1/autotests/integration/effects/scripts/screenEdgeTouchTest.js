registerTouchScreenEdge(1, function() {
    sendTestResponse("triggered");
});
