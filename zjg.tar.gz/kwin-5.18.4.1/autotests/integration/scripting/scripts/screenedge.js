registerScreenEdge(readConfig("Edge", 1), function() { workspace.slotToggleShowDesktop(); });
