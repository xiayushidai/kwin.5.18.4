registerTouchScreenEdge(readConfig("Edge", 1), function() { workspace.slotToggleShowDesktop(); });
